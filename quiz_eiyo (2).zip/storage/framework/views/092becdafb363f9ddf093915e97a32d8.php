

<?php $__env->startSection('content'); ?>
    <h2>Edit Users</h2>

    <form action="<?php echo e(url('users/' . $row->id)); ?>" method="post">
        <input type="hidden" name="_method" value="PATCH">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="">NAMA</label>
            <input type="text" name="name" id="" class="form-control" value="<?php echo e($row->name); ?>">
        </div>
        <div class="mb-3">
            <label for="">EMAIL</label>
            <input type="text" name="email" id="" class="form-control" value="<?php echo e($row->email); ?>">
        </div>
        <div class="mb-3">
            <label for="">PASSWORD</label>
            <input type="text" name="password" id="" class="form-control" value="<?php echo e($row->password); ?>">
        </div>
        <div class="mb-3">
            <input type="submit" value="UPDATE" class="btn btn-primary">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quizdiva-pbwl\resources\views/users/edit.blade.php ENDPATH**/ ?>