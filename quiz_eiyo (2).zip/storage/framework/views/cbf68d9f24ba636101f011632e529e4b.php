
<?php $__env->startSection('content'); ?>

<h2>Users</h2>

<a href="<?php echo e(url('users/create')); ?>" class="btn btn-primary mb-3 float-end">+ Add Users</a>

<table class="table table-bordered">
    <tr>
        <th>N0</th>
        <th>NAMA</th>
        <th>EMAIL</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>

    <?php
        $counter = 1; // Inisialisasi variabel counter
    ?>

    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($counter++); ?></td>
            <td><?php echo e($row->name); ?></td>
            <td><?php echo e($row->email); ?></td>
            <td><a href="<?php echo e(url('users/edit/' . $row->id)); ?>" class="btn btn-warning">Edit</a></td>
            <td>
                <form action="<?php echo e(url('users/' . $row->id)); ?>" method="post">
                    <input type="hidden" name="_method" value="DELETE">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Delete" class="btn btn-danger" onclick="return confirm('Are you sure?')">
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quiz_adel\resources\views/users/index.blade.php ENDPATH**/ ?>